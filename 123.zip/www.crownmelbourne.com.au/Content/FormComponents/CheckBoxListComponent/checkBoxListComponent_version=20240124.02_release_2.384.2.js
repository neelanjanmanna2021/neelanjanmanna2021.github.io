﻿document.addEventListener('DOMContentLoaded', function () {
    checkboxListComponent_init();

    // Custom kentico-form- events are dispatched via /Kentico/Scripts/forms/updatableFormHelper.js
    document.addEventListener('kentico-form-update-after', function (e) {
        checkboxListComponent_init();
    }, false);

    document.addEventListener('kentico-form-submitted', function (e) {
        checkboxListComponent_init();
    }, false);
}, false);

function checkboxListComponent_init() {
    var checkBoxLists = document.querySelectorAll('div[class="ktc-checkbox-list"]');
    for (var i = 0; i < checkBoxLists.length; i++) {
        var fieldName = checkBoxLists[i].getAttribute("data-fieldName");

        checkboxListComponent_updateCheckboxes(fieldName);
        checkboxListComponent_updateSelectedValues(fieldName);
        checkboxListComponent_bind(fieldName);
    }
}

function checkboxListComponent_updateCheckboxes(fieldName) {
    var hiddenSelectedValues = document.querySelector('input[type="hidden"][data-fieldName="' + fieldName + '"][id$="SelectedValues"]');
    if (hiddenSelectedValues.value === null)
            return;
        var selectedValuesArray = hiddenSelectedValues.value.split('|');
        for (var i = 0; i < selectedValuesArray.length; i++) {
            var checkboxid = fieldName + "_" + selectedValuesArray[i] + "_checkbox";
            var elem = document.getElementById(checkboxid);
            if (elem !== null)
                elem.checked = true;
        }
}

function checkboxListComponent_updateSelectedValues(fieldName) {
        var checkedValues = "";
        var checkboxes = document.querySelectorAll('input[type="checkbox"][data-fieldName="' + fieldName + '"]');
        for (var i = 0; i < checkboxes.length; i++) {
            if (checkboxes[i].checked) {
                var checkedValuesElem = document.getElementById(checkboxes[i].id);
                if (checkedValuesElem !== null)
                    checkedValues += checkedValuesElem.value + "|";
            }
        }
        if (checkedValues !== "")
            checkedValues = checkedValues.substring(0, checkedValues.length - 1);
    var hiddenSelectedValues = document.querySelector('input[type="hidden"][data-fieldName="' + fieldName + '"][id$="SelectedValues"]');
    if (hiddenSelectedValues !== null)
        hiddenSelectedValues.value = checkedValues;
}

function checkboxListComponent_updateSelectedValuesClick() {   
    var fieldName = this.getAttribute("data-fieldName");
    checkboxListComponent_updateSelectedValues(fieldName);
}

function checkboxListComponent_selectAllValues() {
    var fieldName = this.getAttribute("data-fieldName");
    var checkboxes = document.querySelectorAll('input[type="checkbox"][data-fieldName="' + fieldName + '"]');
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = this.checked;
    }
    checkboxListComponent_updateSelectedValues(fieldName);
}

function checkboxListComponent_bind(fieldName) {
    var checkboxes = document.querySelectorAll('input[type="checkbox"][data-fieldName="' + fieldName + '"]');
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].value === "all") {
            checkboxes[i].onclick = checkboxListComponent_selectAllValues;
        } else {
            checkboxes[i].onclick = checkboxListComponent_updateSelectedValuesClick;
        }
    }
}