document.addEventListener('DOMContentLoaded', function () {
    dateSelectComponent_init();

    // Custom kentico-form- events are dispatched via /Kentico/Scripts/forms/updatableFormHelper.js
    document.addEventListener('kentico-form-update-after', function (e) {
        dateSelectComponent_init();
    }, false);

    document.addEventListener('kentico-form-submitted', function (e) {
        dateSelectComponent_init();
    }, false);
}, false);

function dateSelectComponent_init() {
    var dateSelects = document.querySelectorAll('div[class="dateselectcomponent"]');
    for (var i = 0; i < dateSelects.length; i++) {
        var fieldName = dateSelects[i].getAttribute("data-fieldName");
        dateSelectComponent_updateSelects(fieldName);
        dateSelectComponent_updateDateSelected(fieldName);
        dateSelectComponent_bind(fieldName);
    }
}

function dateSelectComponent_updateSelects(fieldName) {
    var hiddenDateSelected = document.querySelector('input[type="hidden"][data-fieldName="' + fieldName + '"][id$="DateSelected"]');
    if (hiddenDateSelected.value === null || hiddenDateSelected.value === "")
        return;

    var daySelector = document.querySelector('#dateselectcomponent-day-' + fieldName);
    daySelector.value = parseInt(hiddenDateSelected.value.substr(8, 2));
    var monthSelector = document.querySelector('#dateselectcomponent-month-' + fieldName);
    monthSelector.value = parseInt(hiddenDateSelected.value.substr(6, 2));
    var yearSelector = document.querySelector('#dateselectcomponent-year-' + fieldName);
    yearSelector.value = parseInt(hiddenDateSelected.value.substr(0, 4));
}

function dateSelectComponent_updateDateSelected(fieldName) {
    var selectedDay = document.querySelector('#dateselectcomponent-day-' + fieldName).value;
    var selectedMonth = document.querySelector('#dateselectcomponent-month-' + fieldName).value;
    var selectedYear = document.querySelector('#dateselectcomponent-year-' + fieldName).value;

    var hiddenDateSelected = document.querySelector('input[type="hidden"][data-fieldName="' + fieldName + '"][id$="DateSelected"]');
    if (hiddenDateSelected === null)
        return;

    if (selectedDay === "" || selectedMonth === "" || selectedYear === "") {
        hiddenDateSelected.value = "";
        return;
    }

    var selectedDate = selectedYear + "-" + zeroPad(selectedMonth, 2) + "-" + zeroPad(selectedDay, 2);
    var errorLabel = document.querySelector('div[class^="field-validation-"][data-valmsg-for$="' + fieldName + '.DateSelected"]');
    if (!isValidDate(selectedDate)) {
        var errorMessage = document.querySelector('div[class^="dateselectcomponent"][data-fieldName="' + fieldName + '"]').dataset.errorMessage;        
        errorLabel.innerHTML = errorMessage;
        errorLabel.className = 'field-validation-error';
        return;
    }

    errorLabel.innerHTML = '';
    errorLabel.className = 'field-validation-valid';
    hiddenDateSelected.value = selectedYear + "-" + zeroPad(selectedMonth, 2) + "-" + zeroPad(selectedDay, 2);
}

const zeroPad = (num, places) => String(num).padStart(places, '0')

function isValidDate(dateObject) {
    var tempDate = new Date(dateObject);
    return tempDate.toString() !== 'Invalid Date' && tempDate.toISOString().substr(0,10) === dateObject;
}

function dateSelectComponent_bind(fieldName) {
    var dateSelectors = document.querySelectorAll('select[id$="' + fieldName + '"]');
    for (var i = 0; i < dateSelectors.length; i++) {
        dateSelectors[i].onchange = dateSelectComponent_updateDateSelectedHandler;
    }
}

function dateSelectComponent_updateDateSelectedHandler() {
    var fieldName = this.getAttribute("data-fieldName");
    dateSelectComponent_updateDateSelected(fieldName);
}