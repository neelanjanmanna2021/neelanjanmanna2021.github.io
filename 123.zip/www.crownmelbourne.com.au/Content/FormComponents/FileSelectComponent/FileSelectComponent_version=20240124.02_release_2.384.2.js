document.addEventListener('DOMContentLoaded', function () {
    fileSelectComponent_init();

    // Custom kentico-form- events are dispatched via /Kentico/Scripts/forms/updatableFormHelper.js
    document.addEventListener('kentico-form-update-after', function (e) {
        fileSelectComponent_init();
    }, false);

    document.addEventListener('kentico-form-submitted', function (e) {
        fileSelectComponent_init();
    }, false);
}, false);

function fileSelectComponent_init() {
    var dateSelects = document.querySelectorAll('input[type="file"][data-fieldtype="fileselect"]');
    dateSelects.forEach(ds => {
        ds.onchange = fileSelectComponent_onchangeHandler;
    });
}

function fileSelectComponent_onchangeHandler() {
    var fieldName = this.dataset.fieldname;
    var errorLabel = document.querySelector('div[class^="field-validation-"][data-valmsg-for$="' + fieldName + '.FileSelected"]');

    if (!fileSelectComponent_isValidFileExtension(this)) {
        this.value = "";
        errorLabel.innerHTML = this.dataset.accepterrormessage;
        errorLabel.className = 'field-validation-error';
        return;
    }

    if (!fileSelectComponent_isLessThanMaxFileSize(this)) {
        this.value = "";
        errorLabel.innerHTML = this.dataset.maxfilesizeerrormessage;
        errorLabel.className = 'field-validation-error';
        return;
    }

    errorLabel.innerHTML = '';
    errorLabel.className = 'field-validation-valid';
}

function fileSelectComponent_isValidFileExtension(fileInputElement) {
    var acceptList = fileInputElement.getAttribute("accept");

    if (fileInputElement.value === "" || acceptList === null)
        return true;

    if (fileInputElement.value.length < 5 || !fileInputElement.value.includes("."))
        return false;

    var fileExtension = fileInputElement.value.substr(fileInputElement.value.length - 4, 4);

    return acceptList.includes(fileExtension);
}

function fileSelectComponent_isLessThanMaxFileSize(fileInputElement) {
    if (fileInputElement.value === "")
        return true;

    var maxFileSizeMB = fileInputElement.dataset.maxfilesizemb;
    if (maxFileSizeMB === undefined)
        maxFileSizeMB = 5; // default to 5MB

    if (maxFileSizeMB === 0)
        return true;

    var maxMBs = parseInt(maxFileSizeMB);
    var maxBytes = maxMBs * 1024 * 1024;

    return (fileInputElement.files[0].size < maxBytes);
}