﻿document.addEventListener('DOMContentLoaded', function () {
    if (!window.location.pathname.indexOf("-confirmation"))
        return;

    var scrollEventTriggered = false;
    document.addEventListener('scroll', function () {
        if (!scrollEventTriggered) {
            populatePlaceholders();
            scrollEventTriggered = true;
        }
    });
    setTimeout(function () { populatePlaceholders(); }, 500);
}, false);

function populatePlaceholders() {
    var richTexts = document.querySelectorAll("div[data-testid='rich-text'");
    richTexts.forEach(rt => {
        var richTextContent = rt.querySelector("div[class^='paragraph']");
        if (richTextContent !== null)
            richTextContent.innerHTML = replaceParams(richTextContent.innerHTML);
    });
}

function replaceParams(richTextContent) {
    var queryParams = new URLSearchParams(window.location.search);
    for (var key of queryParams.keys()) {
        richTextContent = richTextContent.replace(`{${key}}`, queryParams.get(key));        
    };
    return richTextContent;
}